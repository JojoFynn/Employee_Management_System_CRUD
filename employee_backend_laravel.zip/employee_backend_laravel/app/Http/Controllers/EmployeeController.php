<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function getEmployee(){
        return response()->json(Employee::all(),200);
    }

    public function getEmployeeById($id){
        $employee = Employee::find($id);
        if(is_null($employee)){
           return response()->json(['message' => 'Employee Not Found'],404);
        }
        return response()->json($employee::find($id),200);
    }

    public function addEmployee(Request $request)
    {
        // Validate the incoming JSON data
        $validatedData = $request->validate([
            'name' => 'required|string',
            'email' => 'required|email',
            'salary' => 'required|numeric',
        ]);

        // Create the employee record
        $employee = Employee::create($validatedData);

        // Return the response with status code 201 (Created)
        return response($employee, 201);
    }

    public function updateEmployeeById(Request $request, $id){
        $employee = Employee::find($id);
        if(is_null($employee)){
            return response()->json(['message' => 'Employee Not Found'],404);
         }
         $employee -> update($request->all());
         return response($employee,200);
    }

    public function deleteEmployeeById(Request $request, $id)
    {
        $employee = Employee::find($id);
        if (is_null($employee)) {
            return response()->json(['message' => 'Employee Not Found'], 404);
        }
    
        $deletedId = $employee->id; // Store the ID before deleting
    
        $employee -> delete(); //Delete functionality
    
        return response()->json(['message' => 'Record of id: ' . $deletedId . ' was deleted'], 200);
    }
    

}
